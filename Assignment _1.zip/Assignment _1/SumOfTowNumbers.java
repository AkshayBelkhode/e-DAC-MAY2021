class SumOfTowNumbers
{
	public static void main(String[] args)
	{
		//int a = 74, b = 34, sum;
		//sum=a+b;
		//System.out.println(sum);
		
		System.out.println(74+36);
		
	}
}