import java.util.Scanner; 
class BinaryToOctal
{
	public static void main (String [] args) 
	{

			int numl;

			Scanner tata= new Scanner (System.in); 
			int numl= Integer.parseInt (tata.nextLine(), 2);
			 System.out.println (Integer.toOctalString (num1)); 
	 }

}