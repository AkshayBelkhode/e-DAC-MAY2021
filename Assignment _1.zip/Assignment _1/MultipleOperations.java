class MultipleOperations
{
	public static void main(String[] args)
	{
		int a = 5, b = 8, c = 6 , ans,mod,sol,sol2;
		int d=55,e = 9 , f=20, g=3 ,h=15 ,i=2;
			
			//a. -5 + 8 * 6
			
			ans = -a+b*6;
			System.out.println(ans);
		
			//	b. (55+9) % 9
			mod = (d+e)%e;
			System.out.println(mod);
			
			//c. 20 + -3*5 / 8
			sol = f + -g*a/b;
			System.out.println(sol);
			
			//d. 5 + 15 / 3 * 2 - 8 % 3
			sol2 = a+h/g*i-b%g;
			System.out.println(sol2);
		

	}
}
