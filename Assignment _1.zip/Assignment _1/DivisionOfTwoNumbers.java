class DivisionOfTwoNumbers
{
	public static void main(String[] args)
	{
		//int a = 50 , b = 3 , div;
		//div = a/b;
		//System.out.println(div);
		
		System.out.println("50/3 = "+ 50/3);
	}
}