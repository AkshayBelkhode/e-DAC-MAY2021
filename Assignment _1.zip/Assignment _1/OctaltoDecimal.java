/*
25. Write a Java program to convert a octal number to a decimal number.
Input Data:
Input any octal number: 10
Expected Output
Equivalent decimal number: 8
*/
class OctaltoDecimal{
	public static void main(String [] args)
	{
		String octalString="10";  
		//Converting octal number into decimal  
		int decimal=Integer.parseInt(octalString,8); 
		System.out.println(decimal);
}
}