/*18. Write a Java program to multiply two binary numbers.

Input Data:
Input the first binary number: 10
Input the second binary number: 11
Expected Output
Product of two binary numbers: 110 *\
