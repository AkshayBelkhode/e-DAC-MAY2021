/*24. Write a Java program to convert a binary number to a Octal number.
Input Data:
Input a Binary Number: 111
Expected Output
Octal number: 7
*/
import java.util.Scanner;

class BinaryToOctal1
{
	public static void main(String [] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Binary No");
		String binary = sc.next();
		//convert Binary to Decimal
		int decimal = Integer.parseInt(binary,2);
		System.out.println("Decimal No = "+decimal);
		String octal = Integer.toOctalString(decimal);
	}
}
