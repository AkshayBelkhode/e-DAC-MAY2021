class AreaAndPerimeterCircle
{
	private static final double radius=7.5;
	public static void main(String[]args)
	{
		double Perimeter = 2* Math.PI*radius;   //2*pi*r
		double Area  =Math.PI*radius*radius;		//pi* r*r
	
		System.out.println("Perimeter = "+Perimeter);
		System.out.println("Area = "+Area);
	}
	
} 