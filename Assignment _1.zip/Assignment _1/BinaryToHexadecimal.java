/*23. Write a Java program to convert a binary number to hexadecimal number.
Input Data:
Input a Binary Number: 1101
Expected Output
HexaDecimal value: D
*/
class BinaryToHexadecimal 
{
	
}