/*6. Write a Java program to print the sum (addition), multiply, subtract, divide and
remainder of two numbers.
Test Data:
Input first number: 125
Input second number: 24
Expected Output :
125 + 24 = 149
125 - 24 = 101
125 x 24 = 3000
125 / 24 = 5
125 mod 24 = 5
*/
import java.util.Scanner;
class MultipleAction
{
	public static void main(String[] args)
	{
		int sum, mul, sub, div ,rem;
		Scanner myOdj = new Scanner(System.in);
		System.out.println("Enter The First Number");
		int Fnum = myOdj.nextInt();
		System.out.println("Enter Second Number");
		int Snum = myOdj.nextInt();
		sum = Fnum+Snum;
		sub = Fnum-Snum;
		mul = Fnum*Snum;
		div = Fnum/Snum;
		rem = Fnum%Snum;
		System.out.println("print the sum (addition), multiply, subtract, divide and remainder of Given numbers");
		System.out.println(Fnum+" + "+Snum+"   = "+sum);
		System.out.println(Fnum+" - "+Snum+"   = "+sub);
		System.out.println(Fnum+" x "+Snum+"   = "+mul);
		System.out.println(Fnum+" x "+Snum+"   = "+div);
		System.out.println(Fnum+" mod "+Snum+" = "+rem);
		
	}
}