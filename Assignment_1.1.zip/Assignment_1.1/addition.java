class addition
{
public static void main(String [] args)

{
int a=74, b=36, c= a + b;

 
System.out.println("Sum of 74 and 36 is  "+c);

}
}
