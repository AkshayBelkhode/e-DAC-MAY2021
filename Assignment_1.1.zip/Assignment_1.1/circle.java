class circle
{
	public static void main(String []args)
	{
		double pi=3.141592653589793238;
		double r=7.5;
		System.out.println("Peremeter is = "+(2*pi*r));
		System.out.println("Area is = "+ (pi *(r*r)));
		
	}
	
}