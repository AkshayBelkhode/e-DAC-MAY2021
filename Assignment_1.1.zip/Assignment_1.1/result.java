class result
{
public static void main(String [] args)
{
System.out.println("-5+8*6="+(-5+8*6));
System.out.println("(55+9) % 9="+(55+9) % 9);
System.out.println("20 + -3*5 / 8= "+( 20 + -3*5 / 8));
System.out.println("5 + 15 / 3 * 2 - 8 % 3 ="+(5 + 15 / 3 * 2 - 8 % 3));

}
}