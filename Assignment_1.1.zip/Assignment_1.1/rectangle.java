class rectangle
{
public static void main(String []args)
{
float w= 5.6lf;
float h= 8.5f;
System.out.println("Area is 5.6*8.5 = "+(w * h));
System.out.println("Peremeter is 2 * (5.6 + 8.5) ="+(2*(w+h)));
}
}