class swap
{
	public static void main(String[]args)
	{
		int i = 10;
		int j = 20;
		int temp;
		
		
		temp=i;
		i=j;
		j=temp;
		
		System.out.println("i= "+i);
		System.out.println("j= "+temp);
		
		
	}
}